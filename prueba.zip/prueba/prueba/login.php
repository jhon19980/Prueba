<?php session_start();
?>
<!DOCTYPE html>
<html>

<head>
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body>

</body>

</html>
<?php
include('dist/includes/dbcon.php');

if (isset($_POST['login'])) {

	$usuario_valido = false;
	$user_unsafe = $_POST['username'];
	$pass_unsafe = $_POST['password'];


	$user = mysqli_real_escape_string($con, $user_unsafe);
	$pass1 = mysqli_real_escape_string($con, $pass_unsafe);

	$pass = md5($pass1);
	$salt = "a1Bz20ydqelm8m1wql";
	$pass = $salt . $pass;

	date_default_timezone_set('Asia/Manila');

	$date = date("Y-m-d H:i:s");

	$query = mysqli_query($con, "select * from usuario where  usuario='$user' and password='$pass' ") or die(mysqli_error($con));
	$row = mysqli_fetch_array($query);
	$id = $row['id'];
	$name = $row['usuario'];
	$counter = mysqli_num_rows($query);
	$_SESSION['id'] = $id;
	$_SESSION['name'] = $name;
}

?>
<?php if ($counter == 0) { ?>
	<script>
		Swal.fire({
			icon: "error",
			title: "Oops...",
			text: "  Usuario o pasword incorrectos! ",
			showConfirmButton: true,
			confirmButtonText: "Cerrar"
		}).then(function(result) {
			if (result.value) {
				window.location = "index.php";
			}
		});
	</script>

<?php } ?>
<?php if ($counter > 0) { ?>

	<script>
		Swal.fire({
			icon: "success",
			title: "Sesión Iniciada",
			text: " Bienvenido Prueba ",
			showConfirmButton: true,
		}).then(function(result) {
			if (result.value) {
				window.location = "pagina/layout/inicio.php";
			}
		});
	</script>';

<?php } ?>

