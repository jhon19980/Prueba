<!--A Design by Jhon Alexander P
Author: ElectroSystem
Author URL: http://electrosistem.com.co
License: Creative Commons Attribution 1.0 Unported

-->

<?php session_start();

?>

<?php
include('../../pagina/layout/session.php')
?>

<?php
require('../../dist/includes/dbcon.php');
?>


<?php include '../layout/header.php';
$id = $_SESSION['id']; //Este es el ID del Usuario
//echo 'id usuario...' . $id;
?>

<?php $fecha = date('Y-m-d'); ?>


<!-- Font Awesome -->
<link rel="stylesheet" href="../layout/plugins/datatables/dataTables.bootstrap.css">
<link href="https://cdn.datatables.net/v/dt/jq-3.6.0/jszip-2.5.0/dt-1.13.4/b-2.3.6/b-colvis-2.3.6/b-html5-2.3.6/b-print-2.3.6/datatables.min.css" rel="stylesheet" />
<link rel="stylesheet" href="../layout/apps/dist/css/adminlte.min.css">
<link rel="stylesheet" href="../layout/plugins/select2/select2.min.css">


<!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
<link rel="stylesheet" href="../layout/dist/css/skins/_all-skins.min.css">

<style>
  .foter {
    position: fixed;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    background-color: black;
    color: white;
    margin-top: 8rem;
    text-align: center;
    bottom: 0;
  }
</style>

<style>
  .contenedor {
    width: 1000px;
    /* Ancho fijo */
    overflow-x: scroll;
    /* Habilitar scroll horizontal */
  }
</style>

<!-- Tambien se puede colocar sm -->

<body class="hold-transition sidebar-mini">

  <div class="wrapper">

    <?php include '../layout/main_sidebar.php'; ?>

    <!-- top navigation -->


    </aside>
    <?php include '../layout/top_nav.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">PRUEBA</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">LISTADO</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->

        <button href="modalIngreso" type="button" class="btn btn-warning btn-print" data-toggle="modal" data-target="#modalIngreso">
          REGISTRAR
        </button>

        <div class="modal fade bd-example-modal-xl" id="modalIngreso" tabindex="-1" role="dialog" aria-labelledby="modalIngreso" aria-hidden="true">
          <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="modalIngreso">INGRESAR DATOS </h5>

              </div>

              <div class="modal-body">
                <form class="row" action="cliente_add.php" method="post" enctype='multipart/form-data' name="form1">

                  <div class="col-6">
                    <label for="activo" class="form-label">Nombre Vendedor o Supervisor</label>
                    <input type="text" class="form-control" id="nombre_ven" name="nombre_ven" placeholder="Nombre">
                  </div>

                  <div class="col-6">
                    <label for="cargo_ven" class="form-label">Seleccionar Cargo</label>
                    <select id="cargo_ven" name="cargo_ven" class="form-control select2">
                      <option value="">Seleccionar Cargo</option>
                      <option value="vendedor">Vendedor</option>
                      <option value="supervisor">Supervisor</option>
                    </select>
                  </div>

                  <div class="col-6">
                    <label for="activo" class="form-label">Cantidad de venta</label>
                    <input type="number" class="form-control" id="cantidad_ven" name="cantidad_ven" placeholder="Cantidad">
                  </div>
                  <div class="col-6">
                    <label for="activo" class="form-label">Correo</label>
                    <input type="text" class="form-control" id="correo" name="correo" placeholder="Correo">
                  </div>
                  <div class="col-6">
                    <label for="fecha" class="form-label">fecha</label>
                    <input type="number" class="form-control" id="fecha" name="fecha" value="<?php echo $fecha ?>" readonly="" placeholder="Fecha Ejecucion">
                  </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-dark" name="editar">Guardar</button>
              </div>
              </form>
            </div>
          </div>
        </div>

        <button href="comisionesModal" type="button" class="btn btn-warning btn-print" data-toggle="modal" data-target="#comisionesModal">
          Comisiones Supervisor
        </button>
        <div class="modal fade" id="comisionesModal" tabindex="-1" role="dialog" aria-labelledby="comisionesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="comisionesModalLabel">Comision del supervisor</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <table id="comisionesTable" class="table table-bordered table-hover">
                <thead>
                  <tr class=" btn-dark">
                    <th>#</th>
                    <th>Cantidad Ventas</th>
                    <th>Comisión</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  // Obtener la suma total de ventas de los vendedores
                  $query_suma = mysqli_query($con, "SELECT SUM(cantidad_ven) AS total_ventas FROM vendedores") or die(mysqli_error($con));
                  $row_suma = mysqli_fetch_array($query_suma);
                  $suma_ventas = $row_suma['total_ventas'];

                  // Cálculo de la comisión para el supervisor
                  $comision_supervisor = $suma_ventas * 0.1; // 10% de la suma total de ventas
                  ?>
                  <tr>
                    <td>Supervisor</td>
                    <td><?php echo $suma_ventas; ?></td>
                    <td><?php echo $comision_supervisor; ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
          </div>
        </div>
      </div>

      </div>

     

      <div class="content">
        <div class="container-fluid">
          <div class="box-body">
            <div class="box-body" style=" overflow-x:auto">
              <div class="table-responsive-xl">
                <table id="example1" class="table table-bordered table-hover">
                  <thead>
                    <tr class=" btn-dark">
                      <th>#</th>
                      <th>Vendedor</th>
                      <th>Cargo</th>
                      <th>Cantidad Ventas</th>
                      <th>Correo</th>
                      <th>Fecha</th>
                      <th>Comisión</th>
                      <th class="btn-print">Acción</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $query = mysqli_query($con, "SELECT * FROM vendedores") or die(mysqli_error($con));
                    $i = 0;
                    while ($row = mysqli_fetch_array($query)) {
                      $id_vendedor = $row['id_vendedor'];
                      // Cálculo de la comisión para cada vendedor
                      $comision = $row['cantidad_ven'] * 0.3; // 30% de la cantidad de ventas
                      $i++;
                    ?>
                      <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $row['nombre_ven']; ?></td>
                        <td><?php echo $row['cargo_ven']; ?></td>
                        <td><?php echo $row['cantidad_ven']; ?></td>
                        <td><?php echo $row['correo']; ?></td>
                        <td><?php echo $row['fecha']; ?></td>
                        <td><?php echo $comision; ?></td>
                        <td><button type="button" class="btn btn-primary">Editar</button></td>
                      </tr>
                    <?php } ?>
                  </tbody>

                </table>
              </div>
            </div>
          </div>
        </div><!-- /.box-body -->
      </div><!-- /.col -->
    </div><!-- /.row -->


    <footer class="main-footer">
      <!-- To the right -->

      <div class="float-right d-none d-sm-inline">
        DESARROLLADO POR JHON ALEXANDER PATIÑO
      </div>
      <!-- Default to the left -->
      <strong>Copyright &copy; 2021-2023 </strong> All rights reserved.

    </footer>
  </div><!-- /.box-body -->


  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->

  <!-- jQuery -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <!-- Bootstrap 4 -->
  <script src="//cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/v/dt/jq-3.6.0/jszip-2.5.0/dt-1.13.4/b-2.3.6/b-colvis-2.3.6/b-html5-2.3.6/b-print-2.3.6/datatables.min.js"></script>

  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>

  <?php include '../layout/datatable_script.php'; ?>

  <script>
    $(function() {
      $('#example1').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": true,
      });
    });
  </script>

</body>

</html>