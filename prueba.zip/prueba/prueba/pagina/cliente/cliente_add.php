<?php
session_start();

//include('../dbcon.php');
include('../../dist/includes/dbcon.php');

//$branch=$_SESSION['branch'];
$nombre = $_POST['nombre_ven'];
$cargo = $_POST['cargo_ven'];
$cantidad = $_POST['cantidad_ven'];
$correo = $_POST['correo'];
$fecha = $_POST['fecha'];


$id_usuario = $_SESSION['id']; //Id usuario del sistema
//echo $id_usuario;

		mysqli_query($con, "INSERT INTO vendedores(nombre_ven,cargo_ven,correo,cantidad_ven,fecha)
				VALUES('$nombre','$cargo','$correo','$cantidad','$fecha')") or die(mysqli_error($con));


		echo "<script>document.location='../cliente/cliente.php'</script>";
		header('Location:../cliente/cliente.php');

